def stat_chains():
    pass
